# LONG AUTO WALKER PRO  (Minecraft 1.21.11 - Fabric)

Addon Meteor Client: tu di chuyen (Baritone) den cho can xay theo schematic Litematica; tu lay vat lieu tu ruong; Auto Glass bridge.

## TRANG THAI THAT (doc truoc)
- Ma nguon da viet day du, **CHUA duoc build thanh JAR** (moi truong tao khong co mang/Minecraft/Gradle).
- Da kiem tra: moi lenh goi vao Meteor/Baritone/Litematica duoc doi chieu voi 3 file JAR that (javap) va `javac` khong bao loi cu phap / loi symbol cua 3 mod.
- Chua kiem tra: bien dich day du voi Minecraft+Yarn, va chay thuc te trong game. Ten ham Minecraft (Yarn 1.21.11) viet tu kien thuc, co the can sua nho khi bien dich lan dau -> gui log lai de sua.

## Build (GitHub Codespaces)
1. Dat vao `libs/`: `meteor-client-1_21_11-86_8.jar`, `baritone-api-fabric-1_17_0.jar`, `litematica-fabric-1_21_11-0_26_16_2.jar` va **`malilib-fabric-1.21.11-0.27.x.jar`** (>= 0.27.19, < 0.28.0 - Litematica yeu cau). `orbit-0.2.4.jar` da co san.
2. Doi chieu phien ban trong `gradle.properties` voi https://fabricmc.net/develop (chon 1.21.11): `yarn_mappings`, `loader_version`, `loom_version`, `fabric_version`. (Cac gia tri hien tai la uoc luong.)
3. Tao Gradle wrapper (thieu gradle-wrapper.jar):
   `sdk install gradle 9.2.0 && gradle wrapper --gradle-version 9.2.0` roi `./gradlew build`
4. JAR nam o `build/libs/long-auto-walker-pro-1.0.0.jar` (khong dung file `-sources`).

## Cai dat
Bo vao `mods/`: Fabric Loader >= 0.18.2, Fabric API, Meteor Client 1.21.11-86, Baritone 1.17.0, Litematica 0.26.16, MaLiLib 0.27.19+, va file JAR cua mod nay. Khong sua JAR goc.

## Su dung
- Phim mac dinh (doi trong Menu > SETTINGS hoac Meteor GUI): **K** mo Menu, **J** Auto Walk, **L** Auto Chest, **;** Auto Glass.
- Trong Litematica: tai schematic va **chon placement**. Bam START WALK. Mod dua ban den cho dung; **ban tu dat block**.
- HUD: Meteor HUD editor > nhom "Long Auto Walker" (FPS, ping, toa do, muc tieu, block tiep, tong/xong/thieu).
- CHEST COORDINATES: nhap theo thu tu Z, Y, X roi SAVE. `+ SELECT BLOCK` dung bang chon cua Meteor (tim kiem, icon, chon nhieu, them/xoa).
- Cau hinh luu o `config/longautowalker.json` (them: `scanBudget`, `clickDelay`, `stockStacks`, `reach`).

## Quy tac an toan da cai dat
- Auto Walk: khong dat/pha block, khong dong inventory. Baritone bi khoa `allowBreak/allowPlace/allowInventory` luc chay, khoi phuc khi dung.
- Auto Chest: chi lay **Item ID chinh xac** nam trong SELECT BLOCK va dang thieu; kiem tra ruong truoc, kiem tra so luong tui sau moi click, dung khi tui day / ruong thieu / server khong mo ruong.
- Auto Glass: mac dinh OFF; chi `minecraft:glass`, chi cau ngang 1 o moi lan, khong dat vao cho schematic can xay, luu toa do va bao can thu hoi, tat neu server tu choi.
- Tren server (khong phai singleplayer) phai tu tick "Allow on servers". Khong gia mao packet, khong ne anti-cheat.
- Dung an toan khi chet / mat ket noi. Chi 1 muc tieu Baritone tai mot thoi diem.

## Gioi han hien tai
- Auto Chest lay nguyen stack (QUICK_MOVE) toi da `stockStacks` stack/loai, co the nhieu hon so thieu mot chut. Chi hoat dong khi Auto Walk dang chay. Ho tro ruong/thung/ruong ender (khong phai shulker).
- Auto Glass chi cau ngang (chua cau doc/dung cot).
- Chu trong giao dien khong dau (font Meteor).
