package vn.truonglong.longautowalker;

import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.screens.settings.ItemListSettingScreen;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Module 7: BlockSelector - danh sach block duoc phep lay tu ruong.
 * Giao dien chon (tim kiem, icon, chon nhieu, them/xoa) dung lai ItemListSettingScreen CO SAN cua Meteor.
 * So khop bang dung ITEM ID (registry), khong dung ten hien thi.
 */
public final class BlockSelector {
    private static ItemListSetting setting;
    private static final Set<Identifier> selectedIds = new HashSet<>();

    private BlockSelector() { }

    public static synchronized ItemListSetting setting() {
        if (setting == null) {
            setting = new ItemListSetting.Builder()
                .name("selected-blocks")
                .description("Block duoc phep tu dong lay tu ruong.")
                .defaultValue(new ArrayList<Item>())
                .filter(i -> i instanceof BlockItem)
                .onChanged(BlockSelector::onChanged)
                .build();
            List<Item> init = new ArrayList<>();
            for (String s : ConfigManager.d.selectedItems) {
                Identifier id = Identifier.tryParse(s);
                if (id != null && Registries.ITEM.containsId(id)) init.add(Registries.ITEM.get(id));
            }
            setting.set(init);
            onChanged(init);
        }
        return setting;
    }

    private static void onChanged(List<Item> list) {
        selectedIds.clear();
        List<String> out = new ArrayList<>();
        for (Item i : list) {
            Identifier id = Registries.ITEM.getId(i);
            selectedIds.add(id);
            out.add(id.toString());
        }
        ConfigManager.d.selectedItems = out;
        ConfigManager.save();
    }

    /** Nut [ + SELECT BLOCK ]. */
    public static void openScreen(GuiTheme theme) {
        MinecraftClient.getInstance().setScreen(new ItemListSettingScreen(theme, setting()));
    }

    public static boolean isSelected(Item item) {
        setting();
        return selectedIds.contains(Registries.ITEM.getId(item));
    }

    public static int count() { setting(); return selectedIds.size(); }

    // ---------- tien ich inventory dung chung (chi 36 o chinh, so khop theo Item) ----------

    public static Map<Item, Integer> inventorySnapshot() {
        Map<Item, Integer> m = new HashMap<>();
        PlayerInventory inv = MinecraftClient.getInstance().player.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (!s.isEmpty()) m.merge(s.getItem(), s.getCount(), Integer::sum);
        }
        return m;
    }

    public static int invCount(Item item) {
        int n = 0;
        PlayerInventory inv = MinecraftClient.getInstance().player.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(item)) n += s.getCount();
        }
        return n;
    }

    /** So item con nhet them duoc vao 36 o chinh. */
    public static int freeCapacity(Item item) {
        int cap = 0;
        PlayerInventory inv = MinecraftClient.getInstance().player.getInventory();
        ItemStack ref = new ItemStack(item);
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isEmpty()) cap += item.getMaxCount();
            else if (ItemStack.areItemsAndComponentsEqual(s, ref)) cap += Math.max(0, s.getMaxCount() - s.getCount());
        }
        return cap;
    }

    public static String name(Item item) {
        return item.getName().getString() + " (" + Registries.ITEM.getId(item) + ")";
    }
}
