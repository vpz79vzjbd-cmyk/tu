package vn.truonglong.longautowalker;

import baritone.api.pathing.goals.GoalNear;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BarrelBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.EnderChestBlock;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Module 6: AutoChest - lay vat lieu tu ruong da khai bao.
 * Chi lay DUNG Item (so sanh item + component mac dinh), chi nhung item nam trong SELECT BLOCK va dang thieu.
 * Moi click deu duoc kiem tra lai bang so luong trong tui do.
 */
public class AutoChest extends Module {
    private enum S { IDLE, GO, OPEN, WAIT_OPEN, TAKE, CLOSE, WAIT_CLOSE }

    private S s = S.IDLE;
    private long tick, cooldownUntil;
    private int timer, waitTicks, stuckTicks;
    private Vec3d lastPos = Vec3d.ZERO;
    private Map<Item, Integer> wants = new LinkedHashMap<>();
    private final Map<Item, Integer> taken = new HashMap<>();
    private Item need;
    private Item pendItem; private int pendBefore, pendTries;
    private BlockPos chest;

    public AutoChest() {
        super(MeteorIntegration.CATEGORY, "long-auto-chest",
            "Tu lay dung block dang thieu tu ruong da khai bao (theo SELECT BLOCK).");
    }

    public boolean isBusy() { return s != S.IDLE; }

    @Override
    public void onActivate() {
        String e = AutoWalk.precheckCommon();
        if (e != null) { error(e); toggle(); return; }
        s = S.IDLE; cooldownUntil = 0;
    }

    @Override
    public void onDeactivate() { abort(); }

    private void abort() {
        if (mc.player != null && s != S.IDLE && s != S.WAIT_CLOSE && mc.currentScreen != null
            && mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) mc.player.closeHandledScreen();
        s = S.IDLE;
        BaritoneIntegration.cancel();
    }

    private void fail(String msg) {
        error(msg);
        abort();
        cooldownUntil = tick + 600;
    }

    private static boolean isContainer(BlockState st) {
        var b = st.getBlock();
        return b instanceof ChestBlock || b instanceof BarrelBlock || b instanceof EnderChestBlock;
    }

    /** Do AutoWalk goi khi thieu vat lieu `item`. */
    public void request(Item item) {
        if (!isActive() || s != S.IDLE || tick < cooldownUntil || mc.player == null) return;
        ConfigManager.Data d = ConfigManager.d;
        if (!d.hasChest) { warning("Chua luu toa do ruong (CHEST COORDINATES)."); cooldownUntil = tick + 400; return; }
        if (!BlockSelector.isSelected(item)) {
            warning("%s chua co trong SELECT BLOCK nen KHONG lay.", BlockSelector.name(item));
            cooldownUntil = tick + 400; return;
        }
        chest = new BlockPos(d.chestX, d.chestY, d.chestZ);
        if (mc.world.getChunkManager().isChunkLoaded(chest.getX() >> 4, chest.getZ() >> 4)
            && !isContainer(mc.world.getBlockState(chest))) {
            error("Khong tim thay ruong tai %d %d %d.", chest.getX(), chest.getY(), chest.getZ());
            cooldownUntil = tick + 600; return;
        }
        if (BlockSelector.freeCapacity(item) <= 0) {
            warning("Tui do day, khong the lay %s.", BlockSelector.name(item));
            cooldownUntil = tick + 400; return;
        }
        // lap ke hoach: chi item DUOC CHON va THUC SU dang thieu trong schematic
        wants = new LinkedHashMap<>();
        AutoWalk w = Modules.get().get(AutoWalk.class);
        Map<Item, Integer> miss = w.progress().missingByItem();
        miss.putIfAbsent(item, 1);
        for (Map.Entry<Item, Integer> en : miss.entrySet()) {
            Item it = en.getKey();
            if (!BlockSelector.isSelected(it)) continue;
            int cap = it.getMaxCount() * d.stockStacks;
            int want = Math.min(en.getValue(), cap) - BlockSelector.invCount(it);
            if (want > 0) wants.put(it, want);
        }
        if (wants.isEmpty()) { cooldownUntil = tick + 200; return; }
        need = item; taken.clear(); timer = 0; stuckTicks = 0; lastPos = Util.pos(mc.player);
        s = S.GO;
        info("Di lay vat lieu o ruong %d %d %d...", chest.getX(), chest.getY(), chest.getZ());
    }

    @EventHandler
    private void onTick(TickEvent.Post e) {
        tick++;
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) { s = S.IDLE; return; }
        if (s == S.IDLE) return;
        if (p.getHealth() <= 0) { abort(); return; }
        Vec3d c = Vec3d.ofCenter(chest);

        switch (s) {
            case GO -> {
                if (mc.currentScreen != null) return; // cho nguoi choi dong GUI khac
                if (p.getEyePos().distanceTo(c) <= 4.0) { BaritoneIntegration.cancel(); s = S.OPEN; return; }
                BaritoneIntegration.goTo(new GoalNear(chest, 2));
                Vec3d now = Util.pos(p);
                if (now.squaredDistanceTo(lastPos) > 0.25) { lastPos = now; stuckTicks = 0; } else stuckTicks++;
                if (++timer > 1500 || stuckTicks > 300) fail("Khong di toi duoc ruong.");
            }
            case OPEN -> {
                double dx = c.x - p.getEyePos().x, dy = c.y - p.getEyePos().y, dz = c.z - p.getEyePos().z;
                p.setYaw((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
                p.setPitch((float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));
                Direction face = Direction.getFacing(-dx, -dy, -dz);
                Vec3d hitPos = c.add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
                ActionResult r = mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
                    new BlockHitResult(hitPos, face, chest, false));
                if (!r.isAccepted()) { fail("Khong mo duoc ruong (thao tac bi tu choi)."); return; }
                timer = 0; s = S.WAIT_OPEN;
            }
            case WAIT_OPEN -> {
                ScreenHandler h = p.currentScreenHandler;
                if (mc.currentScreen != null && h instanceof GenericContainerScreenHandler) {
                    pendItem = null; waitTicks = 3; s = S.TAKE;
                    checkChestContents((GenericContainerScreenHandler) h);
                } else if (++timer > 40) fail("Server khong mo ruong (tu choi hoac ruong bi khoa).");
            }
            case TAKE -> take(p);
            case CLOSE -> { p.closeHandledScreen(); timer = 0; s = S.WAIT_CLOSE; }
            case WAIT_CLOSE -> {
                if (mc.currentScreen == null || ++timer > 20) { finish(); }
            }
            default -> { }
        }
    }

    /** Buoc 4: kiem tra vat pham trong ruong truoc khi lay. */
    private void checkChestContents(GenericContainerScreenHandler h) {
        int slots = h.getRows() * 9;
        Map<Item, Integer> inChest = new HashMap<>();
        for (int i = 0; i < slots; i++) {
            ItemStack st = h.getSlot(i).getStack();
            if (!st.isEmpty() && wants.containsKey(st.getItem()) && ItemStack.areItemsAndComponentsEqual(st, new ItemStack(st.getItem())))
                inChest.merge(st.getItem(), st.getCount(), Integer::sum);
        }
        for (Item it : wants.keySet())
            if (inChest.getOrDefault(it, 0) == 0) warning("Ruong khong co: %s", BlockSelector.name(it));
        wants.keySet().removeIf(it -> inChest.getOrDefault(it, 0) == 0);
    }

    private void take(ClientPlayerEntity p) {
        ScreenHandler h = p.currentScreenHandler;
        if (!(h instanceof GenericContainerScreenHandler gh) || mc.currentScreen == null) { fail("Ruong da bi dong bat ngo."); return; }
        if (waitTicks > 0) { waitTicks--; return; }

        // kiem tra ket qua click truoc
        if (pendItem != null) {
            int now = BlockSelector.invCount(pendItem);
            if (now <= pendBefore) {
                if (++pendTries > 10) { warning("Click khong co hieu luc (tui day hoac server tu choi). Dung lay."); s = S.CLOSE; }
                return;
            }
            int got = now - pendBefore;
            taken.merge(pendItem, got, Integer::sum);
            wants.computeIfPresent(pendItem, (k, v) -> v - got);
            pendItem = null;
        }
        wants.values().removeIf(v -> v <= 0);
        if (wants.isEmpty()) { s = S.CLOSE; return; }

        int slots = gh.getRows() * 9;
        for (int i = 0; i < slots; i++) {
            ItemStack st = gh.getSlot(i).getStack();
            if (st.isEmpty()) continue;
            Item it = st.getItem();
            if (!wants.containsKey(it)) continue;
            if (!ItemStack.areItemsAndComponentsEqual(st, new ItemStack(it))) continue; // dung bien the mac dinh
            if (BlockSelector.freeCapacity(it) <= 0) { warning("Tui do day. Dung lay."); s = S.CLOSE; return; }
            pendItem = it; pendBefore = BlockSelector.invCount(it); pendTries = 0;
            mc.interactionManager.clickSlot(gh.syncId, i, 0, SlotActionType.QUICK_MOVE, p);
            waitTicks = ConfigManager.d.clickDelay;
            return;
        }
        s = S.CLOSE; // khong con gi de lay
    }

    private void finish() {
        s = S.IDLE;
        cooldownUntil = tick + 40;
        if (taken.isEmpty()) warning("Khong lay duoc gi tu ruong.");
        else taken.forEach((it, n) -> info("Da lay %d x %s", n, BlockSelector.name(it)));
        if (need != null && mc.player != null && BlockSelector.invCount(need) == 0) {
            warning("Ruong khong du %s.", BlockSelector.name(need));
            cooldownUntil = tick + 600;
        }
        BaritoneIntegration.forgetGoal();
    }
}
