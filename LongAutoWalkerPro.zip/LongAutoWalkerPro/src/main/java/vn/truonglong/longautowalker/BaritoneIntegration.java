package vn.truonglong.longautowalker;

import baritone.api.BaritoneAPI;
import baritone.api.IBaritone;
import baritone.api.Settings;
import baritone.api.pathing.goals.Goal;
import baritone.api.process.ICustomGoalProcess;
import net.minecraft.util.math.BlockPos;

/**
 * Module 3: BaritoneIntegration - chi dung de TIM DUONG/DI CHUYEN.
 * Khoa allowBreak/allowPlace/allowInventory de Baritone KHONG tu pha/dat block hay dong vao tui do.
 * Chi co 1 muc tieu (1 tien trinh) tai mot thoi diem: cung goal thi khong gui lai.
 */
public final class BaritoneIntegration {
    private static boolean applied, oBreak, oPlace, oInv;
    private static Goal last;
    private static boolean ours;

    private BaritoneIntegration() { }

    public static boolean available() {
        try { return BaritoneAPI.getProvider().getPrimaryBaritone() != null; } catch (Throwable t) { return false; }
    }

    private static IBaritone b() { return BaritoneAPI.getProvider().getPrimaryBaritone(); }

    public static void applySafeSettings() {
        if (applied) return;
        Settings s = BaritoneAPI.getSettings();
        oBreak = s.allowBreak.value; oPlace = s.allowPlace.value; oInv = s.allowInventory.value;
        s.allowBreak.value = false;
        s.allowPlace.value = false;
        s.allowInventory.value = false;
        applied = true;
    }

    public static void restoreSettings() {
        if (!applied) return;
        Settings s = BaritoneAPI.getSettings();
        s.allowBreak.value = oBreak; s.allowPlace.value = oPlace; s.allowInventory.value = oInv;
        applied = false;
    }

    /** Dat muc tieu moi; neu giong muc tieu dang chay thi bo qua (khong chay trung tien trinh). */
    public static void goTo(Goal g) {
        ICustomGoalProcess p = b().getCustomGoalProcess();
        if (ours && last != null && last.equals(g) && (p.isActive() || b().getPathingBehavior().isPathing())) return;
        last = g;
        ours = true;
        p.setGoalAndPath(g);
    }

    /** Ep tinh duong lai o lan goTo ke tiep (sau khi dat Glass). */
    public static void forgetGoal() { last = null; }

    public static boolean isBusy() {
        IBaritone bar = b();
        return bar.getCustomGoalProcess().isActive() || bar.getPathingBehavior().isPathing();
    }

    /** Chi huy duong di do mod nay bat dau. */
    public static void cancel() {
        if (!ours) return;
        try { b().getPathingBehavior().cancelEverything(); } catch (Throwable ignored) { }
        ours = false;
        last = null;
    }

    public static boolean inGoal(Goal g, BlockPos p) {
        return g != null && g.isInGoal(p.getX(), p.getY(), p.getZ());
    }
}
