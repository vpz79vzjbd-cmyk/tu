package vn.truonglong.longautowalker;

import fi.dy.masa.litematica.data.DataManager;
import fi.dy.masa.litematica.schematic.placement.SchematicPlacement;
import fi.dy.masa.litematica.schematic.placement.SubRegionPlacement;
import fi.dy.masa.litematica.selection.Box;
import fi.dy.masa.litematica.world.SchematicWorldHandler;
import fi.dy.masa.litematica.world.WorldSchematic;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

/** Module 2: LitematicaIntegration - chi DOC schematic dang chon, khong sua schematic. */
public final class LitematicaIntegration {
    private LitematicaIntegration() { }

    public static boolean available() {
        try { selected(); return true; } catch (Throwable t) { return false; }
    }

    /** Placement dang duoc chon trong Litematica (null neu chua chon). */
    public static SchematicPlacement selected() {
        return DataManager.getSchematicPlacementManager().getSelectedSchematicPlacement();
    }

    public static WorldSchematic world() {
        return SchematicWorldHandler.getSchematicWorld();
    }

    /** Khoa nhan dien placement (ten + goc toa do) de luu tien do dung schematic. */
    public static String key(SchematicPlacement p) {
        BlockPos o = p.getOrigin();
        return p.getName() + "@" + o.getX() + "," + o.getY() + "," + o.getZ();
    }

    /** Cac hop {minX,minY,minZ,maxX,maxY,maxZ} cua cac vung con dang bat. */
    public static List<int[]> boxes(SchematicPlacement p) {
        List<int[]> out = new ArrayList<>();
        for (Box b : p.getSubRegionBoxes(SubRegionPlacement.RequiredEnabled.PLACEMENT_ENABLED).values()) {
            BlockPos a = b.getPos1(), c = b.getPos2();
            if (a == null || c == null) continue;
            out.add(new int[]{
                Math.min(a.getX(), c.getX()), Math.min(a.getY(), c.getY()), Math.min(a.getZ(), c.getZ()),
                Math.max(a.getX(), c.getX()), Math.max(a.getY(), c.getY()), Math.max(a.getZ(), c.getZ())});
        }
        return out;
    }

    /** Block schematic tai vi tri (khong khi neu ngoai schematic hoac chua tai). */
    public static BlockState state(BlockPos pos) {
        WorldSchematic w = world();
        return w == null ? Blocks.AIR.getDefaultState() : w.getBlockState(pos);
    }
}
