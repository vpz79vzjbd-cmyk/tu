package vn.truonglong.longautowalker;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.List;

/**
 * Module 8: AutoGlass - NGOAI LE DUY NHAT duoc tu dat block.
 * Chi dat minecraft:glass, chi khi Baritone khong tim duoc duong, chi cau ngang 1 o moi lan,
 * khong dat vao cho schematic can xay, khong pha block, khong thay bang block khac.
 */
public class AutoGlass extends Module {
    private static final int MAX_GLASS = 200;
    private final List<BlockPos> placed = new ArrayList<>();
    private long tick, cooldownUntil, verifyAt;
    private BlockPos verifyPos;
    private int failures;
    private long lastWarn = -10000;

    public AutoGlass() {
        super(MeteorIntegration.CATEGORY, "long-auto-glass",
            "Khi khong co duong: dat Glass lam cau tam (mac dinh TAT). Chi dung minecraft:glass.");
        for (long l : ConfigManager.d.glassPlaced) placed.add(BlockPos.fromLong(l));
    }

    @Override
    public void onActivate() {
        String e = AutoWalk.precheckCommon();
        if (e != null) { error(e); toggle(); return; }
        failures = 0;
        info("AUTO GLASS BAT: chi dat Glass khi khong co duong. Nho thu hoi Glass sau khi xong.");
    }

    @Override
    public void onDeactivate() { reportGlass(); }

    private void persist() {
        List<Long> l = new ArrayList<>();
        for (BlockPos b : placed) l.add(b.asLong());
        ConfigManager.d.glassPlaced = l;
        ConfigManager.save();
    }

    /** Thong bao nhung block Glass can thu hoi (chi liet ke cai con ton tai). */
    public void reportGlass() {
        if (mc.world != null) placed.removeIf(b -> mc.world.getChunkManager().isChunkLoaded(b.getX() >> 4, b.getZ() >> 4)
            && mc.world.getBlockState(b).getBlock() != Blocks.GLASS);
        persist();
        if (placed.isEmpty()) return;
        info("Co %d block Glass can THU HOI (khong tu pha):", placed.size());
        int n = 0;
        for (BlockPos b : placed) {
            if (n++ >= 15) { info("... va %d block nua.", placed.size() - 15); break; }
            info("  Glass: %d %d %d", b.getX(), b.getY(), b.getZ());
        }
    }

    public int glassCount() { return placed.size(); }

    private boolean passable(BlockPos pos) {
        var s = mc.world.getBlockState(pos);
        return s.getCollisionShape(mc.world, pos).isEmpty() && s.getFluidState().isEmpty();
    }

    /**
     * Dat 1 o Glass ngang huong ve `goal`. @return true neu dang xu ly (da dat / cho cooldown), false neu khong the cau.
     */
    public boolean tryBridge(BlockPos goal) {
        ClientPlayerEntity p = mc.player;
        if (!isActive() || p == null || goal == null) return false;
        if (tick < cooldownUntil) return true;
        if (placed.size() >= MAX_GLASS) { warnOnce("Da dat toi da " + MAX_GLASS + " Glass. Hay thu hoi truoc."); return false; }
        if (!p.isOnGround()) return true;

        FindItemResult r = InvUtils.findInHotbar(Items.GLASS);
        if (!r.found()) { warnOnce("Khong co Glass (minecraft:glass) trong hotbar. Khong dat block khac thay the."); return false; }

        BlockPos feet = p.getBlockPos();
        int dx = goal.getX() - feet.getX(), dz = goal.getZ() - feet.getZ();
        if (dx == 0 && dz == 0) return false;
        Direction dir = Math.abs(dx) >= Math.abs(dz) ? (dx > 0 ? Direction.EAST : Direction.WEST)
                                                       : (dz > 0 ? Direction.SOUTH : Direction.NORTH);
        BlockPos ahead = feet.offset(dir), next = ahead.down();

        // kiem tra an toan truoc khi dat (tranh ket / roi)
        if (mc.world.getBlockState(feet.down()).getCollisionShape(mc.world, feet.down()).isEmpty()) return false;
        if (!passable(ahead) || !passable(ahead.up())) return false;           // co tuong chan: khong cau
        if (!mc.world.getBlockState(next).isAir()) return false;               // da co nen: cau khong giup gi
        if (!LitematicaIntegration.state(next).isAir()) return false;          // khong dat vao cho schematic can xay

        boolean ok = BlockUtils.place(next, r, true, 50, true, true);
        if (!ok) {
            if (++failures > 8) { error("Khong dat duoc Glass (server tu choi?). Tat AUTO GLASS."); toggle(); return false; }
            cooldownUntil = tick + 4;
            return true;
        }
        failures = 0;
        placed.add(next);
        persist();
        verifyPos = next; verifyAt = tick + 10;
        cooldownUntil = tick + 8;
        return true;
    }

    @EventHandler
    private void onTick(TickEvent.Post e) {
        tick++;
        if (mc.world == null) return;
        if (verifyPos != null && tick >= verifyAt) {
            if (mc.world.getBlockState(verifyPos).getBlock() != Blocks.GLASS) {
                error("Server tu choi dat Glass tai %d %d %d. Tat AUTO GLASS.", verifyPos.getX(), verifyPos.getY(), verifyPos.getZ());
                placed.remove(verifyPos);
                persist();
                verifyPos = null;
                toggle();
                return;
            }
            verifyPos = null;
        }
    }

    private void warnOnce(String m) {
        if (tick - lastWarn > 300) { lastWarn = tick; warning(m); }
    }
}
