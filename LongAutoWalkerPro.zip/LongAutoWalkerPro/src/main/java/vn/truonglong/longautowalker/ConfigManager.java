package vn.truonglong.longautowalker;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

/** Module 10: ConfigManager - luu/doc cau hinh JSON (config/longautowalker.json). */
public final class ConfigManager {
    public static final class Data {
        public boolean hasChest = false;
        public int chestX, chestY, chestZ;
        public List<String> selectedItems = new ArrayList<>();   // Item ID, vd "minecraft:stone"
        public List<Long> glassPlaced = new ArrayList<>();       // BlockPos.asLong cua Glass da dat
        public boolean allowOnServers = false;                   // chi bat khi server cho phep tu dong hoa
        public double reach = 4.0;
        public int scanBudget = 15000;      // so block quet moi tick (giam neu lag)
        public int clickDelay = 5;          // tick giua 2 lan click trong ruong
        public int stockStacks = 2;         // so stack toi da lay moi loai moi lan
        public String progPlacement = "";   // tien do dang lam do
        public boolean hasProg = false;
        public long progTarget, progStand;
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("longautowalker.json");
    public static Data d = new Data();

    private ConfigManager() { }

    public static synchronized void load() {
        try {
            if (Files.exists(FILE)) {
                Data r = GSON.fromJson(Files.readString(FILE, StandardCharsets.UTF_8), Data.class);
                if (r != null) d = r;
            }
        } catch (Exception e) {
            MainMod.LOG.error("Khong doc duoc config, dung mac dinh", e);
            d = new Data();
        }
        if (d.selectedItems == null) d.selectedItems = new ArrayList<>();
        if (d.glassPlaced == null) d.glassPlaced = new ArrayList<>();
        d.reach = Math.max(2.0, Math.min(4.5, d.reach));
        d.scanBudget = Math.max(1000, Math.min(200000, d.scanBudget));
        d.clickDelay = Math.max(2, Math.min(40, d.clickDelay));
        d.stockStacks = Math.max(1, Math.min(27, d.stockStacks));
    }

    public static synchronized void save() {
        try {
            Path tmp = FILE.resolveSibling(FILE.getFileName() + ".tmp");
            Files.writeString(tmp, GSON.toJson(d), StandardCharsets.UTF_8);
            Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            MainMod.LOG.error("Khong luu duoc config", e);
        }
    }
}
