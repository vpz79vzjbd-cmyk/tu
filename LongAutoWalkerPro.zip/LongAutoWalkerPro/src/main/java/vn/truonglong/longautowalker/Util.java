package vn.truonglong.longautowalker;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

/** Tien ich nho, tranh phu thuoc ten ham doi theo phien ban mapping. */
public final class Util {
    private Util() { }
    public static Vec3d pos(Entity e) { return new Vec3d(e.getX(), e.getY(), e.getZ()); }
}
