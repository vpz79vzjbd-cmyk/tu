package vn.truonglong.longautowalker;

import meteordevelopment.meteorclient.systems.hud.Hud;
import meteordevelopment.meteorclient.systems.hud.HudElement;
import meteordevelopment.meteorclient.systems.hud.HudElementInfo;
import meteordevelopment.meteorclient.systems.hud.HudGroup;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

/** Module 12: HUDManager - HUD (FPS, ping, toa do, muc tieu, block tiep, tien do). Keo tha trong Meteor HUD editor. */
public final class HUDManager {
    public static final HudGroup GROUP = new HudGroup("Long Auto Walker");
    public static final HudElementInfo<LongHud> INFO = new HudElementInfo<>(GROUP, "long-walker-info",
        "FPS, ping, toa do, muc tieu, block tiep theo va tien do xay.", LongHud::new);

    private HUDManager() { }

    public static void register() { Hud.get().register(INFO); }

    public static class LongHud extends HudElement {
        private static final Color WHITE = new Color(255, 255, 255), GOLD = new Color(255, 215, 0), GREEN = new Color(90, 230, 120);
        private long windowStart = System.currentTimeMillis();
        private int frames, fps;

        public LongHud() { super(INFO); }

        private static String xyz(BlockPos p) { return p == null ? "-" : p.getX() + " " + p.getY() + " " + p.getZ(); }

        @Override
        public void render(HudRenderer r) {
            frames++;
            long now = System.currentTimeMillis();
            if (now - windowStart >= 1000) { fps = frames; frames = 0; windowStart = now; }

            MinecraftClient mc = MinecraftClient.getInstance();
            List<String> lines = new ArrayList<>();
            lines.add("LONG AUTO WALKER PRO");
            if (mc.player == null || Modules.get() == null) {
                lines.add("(xem truoc)");
            } else {
                AutoWalk w = Modules.get().get(AutoWalk.class);
                lines.add("FPS: " + fps + "   Ping: " + PlayerUtils.getPing() + " ms");
                lines.add("Vi tri: " + xyz(mc.player.getBlockPos()));
                if (w != null && w.isActive()) {
                    var bp = w.progress();
                    lines.add("Trang thai: " + w.getState());
                    lines.add("Muc tieu: " + xyz(w.getTarget()) + "  (dung: " + xyz(w.getStand()) + ")");
                    lines.add("Block tiep: " + w.nextBlockText());
                    lines.add("Tong: " + bp.total() + "  Xong: " + bp.done() + " (" + bp.percent() + "%)  Thieu: " + bp.missing());
                } else {
                    lines.add("AUTO WALK: OFF");
                }
            }
            double lh = r.textHeight(true) + 2, wmax = 0;
            for (String s : lines) wmax = Math.max(wmax, r.textWidth(s, true));
            setSize(wmax, lh * lines.size());
            double y = this.y;
            for (int i = 0; i < lines.size(); i++) {
                r.text(lines.get(i), this.x, y, i == 0 ? GOLD : (i == 1 ? GREEN : WHITE), true);
                y += lh;
            }
        }
    }
}
