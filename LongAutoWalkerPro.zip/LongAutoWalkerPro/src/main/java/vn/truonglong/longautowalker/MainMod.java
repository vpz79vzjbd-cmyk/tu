package vn.truonglong.longautowalker;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.Version;
import net.fabricmc.loader.api.VersionParsingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Module 1: MainMod - khoi dong, kiem tra dependency, luu cau hinh khi thoat game. */
public class MainMod implements ClientModInitializer {
    public static final String ID = "longautowalker";
    public static final Logger LOG = LoggerFactory.getLogger("LongAutoWalkerPRO");

    /** null = dependency OK, nguoc lai la thong bao loi (cac module se tu choi bat). */
    public static volatile String depsProblem = null;

    @Override
    public void onInitializeClient() {
        ConfigManager.load();
        depsProblem = checkDependencies();
        if (depsProblem != null) LOG.error("Dependency loi: {}", depsProblem);
        else LOG.info("Long Auto Walker PRO: dependency OK (Meteor, Baritone, Litematica, MaLiLib).");
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> ConfigManager.save());
    }

    private static String checkDependencies() {
        FabricLoader fl = FabricLoader.getInstance();
        String[][] req = {
            {"meteor-client", null}, {"baritone", "1.17.0"},
            {"litematica", "0.26.16"}, {"malilib", "0.27.19"}
        };
        for (String[] r : req) {
            var c = fl.getModContainer(r[0]);
            if (c.isEmpty()) return "Thieu mod: " + r[0];
            if (r[1] != null) {
                try {
                    Version have = c.get().getMetadata().getVersion();
                    if (have.compareTo(Version.parse(r[1])) < 0)
                        return r[0] + " qua cu (" + have.getFriendlyString() + "), can >= " + r[1];
                } catch (VersionParsingException ignored) { }
            }
        }
        return null;
    }
}
