package vn.truonglong.longautowalker;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import org.lwjgl.glfw.GLFW;

import java.lang.invoke.MethodHandles;

/**
 * Module 4: MeteorIntegration - dang ky vao Meteor Client duoi dang addon (entrypoint "meteor").
 * Dung he thong module/keybind/HUD/GUI san co cua Meteor, khong tao lai chuc nang.
 */
public class MeteorIntegration extends MeteorAddon {
    public static final Category CATEGORY = new Category("Long Auto Walker");

    @Override
    public void onInitialize() {
        // can thiet de @EventHandler hoat dong trong package cua addon
        MeteorClient.EVENT_BUS.registerLambdaFactory(getPackage(),
            (lookupInMethod, klass) -> (MethodHandles.Lookup) lookupInMethod.invoke(null, klass, MethodHandles.lookup()));

        Modules m = Modules.get();
        m.add(new AutoWalk());
        m.add(new AutoChest());
        m.add(new AutoGlass());
        m.add(new MenuModule());
        defaultKey(m.get(AutoWalk.class), GLFW.GLFW_KEY_J);
        defaultKey(m.get(AutoChest.class), GLFW.GLFW_KEY_L);
        defaultKey(m.get(AutoGlass.class), GLFW.GLFW_KEY_SEMICOLON);
        defaultKey(m.get(MenuModule.class), GLFW.GLFW_KEY_K);
        HUDManager.register();
    }

    private static void defaultKey(Module mod, int key) {
        if (mod != null && !mod.keybind.isSet()) mod.keybind.set(Keybind.fromKey(key));
    }

    @Override
    public void onRegisterCategories() { Modules.registerCategory(CATEGORY); }

    @Override
    public String getPackage() { return "vn.truonglong.longautowalker"; }
}
