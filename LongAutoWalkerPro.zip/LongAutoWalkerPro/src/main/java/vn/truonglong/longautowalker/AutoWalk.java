package vn.truonglong.longautowalker;

import baritone.api.pathing.goals.Goal;
import baritone.api.pathing.goals.GoalBlock;
import baritone.api.pathing.goals.GoalNear;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Module 5: AutoWalk.
 * Doc schematic (Litematica) -> chon block can dat -> Baritone dua nguoi choi den cho dung phu hop.
 * KHONG dat block, KHONG pha block, KHONG dong vao inventory. Nguoi choi tu dat block.
 */
public class AutoWalk extends Module {
    public enum State { IDLE, SEARCHING, WALKING, WAITING_PLACE, WAITING_MATERIAL, CHEST, PAUSED, BLOCKED }

    private final BuildProgress progress = new BuildProgress();
    private State state = State.IDLE;
    private boolean paused;
    private BlockPos target, stand;
    private Item needItem;
    private long tick;
    private final Map<Long, Long> skipUntil = new HashMap<>();
    private int idleTicks, failStreak;
    private Vec3d lastPos = Vec3d.ZERO;
    private long lastMoveTick;
    private long lastMsgTick = -10000;
    private boolean resumeChecked;
    private int placedThisRun;
    private final List<BlockPos> nearbyDone = new ArrayList<>();
    private long nearbyDoneTick = -1000;

    public AutoWalk() {
        super(MeteorIntegration.CATEGORY, "long-auto-walk",
            "Tu di chuyen den vi tri can xay theo schematic Litematica (dung Baritone). Khong tu dat/pha block.");
    }

    // ---------------- getters cho HUD / menu ----------------
    public BuildProgress progress() { return progress; }
    public State getState() { return paused && isActive() ? State.PAUSED : state; }
    public BlockPos getTarget() { return target; }
    public BlockPos getStand() { return stand; }
    public Item getNeedItem() { return needItem; }
    public boolean isPaused() { return paused; }

    public String nextBlockText() {
        if (target == null) return needItem != null ? BlockSelector.name(needItem) : "-";
        return Registries.BLOCK.getId(LitematicaIntegration.state(target).getBlock()).toString();
    }

    // ---------------- dieu khien ----------------
    public void startWalk() {
        if (!isActive()) toggle();
        else if (paused) resumeWalk();
    }

    public void pauseWalk() {
        if (!isActive() || paused) return;
        paused = true;
        BaritoneIntegration.cancel();
        saveProgress();
        info("Da TAM DUNG. Vi tri dang lam do da duoc luu.");
    }

    public void resumeWalk() {
        if (!isActive() || !paused) return;
        paused = false;
        BaritoneIntegration.forgetGoal();
        info("Tiep tuc.");
    }

    public void stopWalk() {
        if (isActive()) toggle();
    }

    // ---------------- vong doi ----------------
    @Override
    public void onActivate() {
        String err = precheck();
        if (err == null) err = progress.start();
        if (err != null) { error(err); toggle(); return; }
        BaritoneIntegration.applySafeSettings();
        paused = false; target = null; stand = null; needItem = null;
        skipUntil.clear(); resumeChecked = false; placedThisRun = 0; failStreak = 0; idleTicks = 0;
        state = State.SEARCHING;
        info("Bat dau quet schematic '%s'...", progress.key());
    }

    @Override
    public void onDeactivate() {
        BaritoneIntegration.cancel();
        BaritoneIntegration.restoreSettings();
        saveProgress();
        progress.stop();
        target = null; stand = null; paused = false;
        state = State.IDLE;
        try {
            AutoGlass g = Modules.get().get(AutoGlass.class);
            if (g != null) g.reportGlass();
        } catch (Throwable ignored) { }
    }

    public static String precheckCommon() {
        if (MainMod.depsProblem != null) return "Dependency loi: " + MainMod.depsProblem;
        var mc = net.minecraft.client.MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return "Chua vao the gioi.";
        if (!mc.isInSingleplayer() && !ConfigManager.d.allowOnServers)
            return "Dang o server: chi bat khi server CHO PHEP tu dong hoa. Tick 'Allow on servers' trong SETTINGS cua menu.";
        return null;
    }

    private String precheck() {
        String e = precheckCommon();
        if (e != null) return e;
        if (!BaritoneIntegration.available()) return "Baritone khong san sang.";
        if (!LitematicaIntegration.available()) return "Litematica khong san sang.";
        return null;
    }

    private void saveProgress() {
        ConfigManager.Data d = ConfigManager.d;
        if (target != null && progress.key() != null && !progress.key().isEmpty()) {
            d.hasProg = true;
            d.progPlacement = progress.key();
            d.progTarget = target.asLong();
            d.progStand = stand != null ? stand.asLong() : target.asLong();
        }
        ConfigManager.save();
    }

    // ---------------- vong lap chinh ----------------
    @EventHandler
    private void onTick(TickEvent.Post e) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.getNetworkHandler() == null) { toggle(); return; }
        if (p.getHealth() <= 0 || p.isDead()) { warning("Nguoi choi da chet. Dung va luu tien do."); toggle(); return; }
        tick++;
        progress.tick(ConfigManager.d.scanBudget, tick);
        if (paused) return;

        AutoChest chest = Modules.get().get(AutoChest.class);
        if (chest != null && chest.isBusy()) { state = State.CHEST; return; }
        if (!progress.hasPublished()) { state = State.SEARCHING; return; }

        // dang dung do tu lan truoc -> tiep tuc
        if (!resumeChecked) {
            resumeChecked = true;
            ConfigManager.Data d = ConfigManager.d;
            if (d.hasProg && progress.key().equals(d.progPlacement)) {
                BlockPos t = BlockPos.fromLong(d.progTarget);
                if (progress.isMissingLive(t) && BlockSelector.invCount(BuildProgress.itemAt(t)) > 0) {
                    info("Tiep tuc vi tri lam do: %d %d %d", t.getX(), t.getY(), t.getZ());
                    setTarget(t);
                }
            }
        }

        // block muc tieu da duoc nguoi choi dat xong?
        if (target != null && progress.isDoneLive(target)) {
            placedThisRun++;
            target = null; stand = null; failStreak = 0; idleTicks = 0;
            BaritoneIntegration.forgetGoal();
        }
        // het vat lieu cho muc tieu hien tai?
        if (target != null && tick % 10 == 0 && BlockSelector.invCount(BuildProgress.itemAt(target)) <= 0) target = null;

        if (target == null || (state == State.WAITING_PLACE && tick % 10 == 0)) choose(p);
        if (target == null) return;

        // da trong tam voi -> cho nguoi choi dat
        if (inReach(p, target)) {
            if (state != State.WAITING_PLACE) BaritoneIntegration.cancel();
            state = State.WAITING_PLACE;
            idleTicks = 0;
            lastMoveTick = tick;
            return;
        }
        walk(p);
    }

    private void choose(ClientPlayerEntity p) {
        long now = tick;
        skipUntil.values().removeIf(t -> t <= now);
        BuildProgress.Pick r = progress.pickNext(Util.pos(p), BlockSelector.inventorySnapshot(),
            l -> skipUntil.containsKey(l));
        if (r.pos != null) {
            needItem = null;
            if (target == null || !r.pos.equals(target)) {
                if (target == null || inReach(p, r.pos)) setTarget(r.pos);
            }
            return;
        }
        target = null; stand = null;
        if (r.noItem > 0) {
            state = State.WAITING_MATERIAL;
            needItem = r.firstNoItem;
            AutoChest chest = Modules.get().get(AutoChest.class);
            if (chest != null && chest.isActive()) chest.request(needItem);
            else notifyEvery(300, "Thieu vat lieu: " + BlockSelector.name(needItem)
                + ". Bat AUTO CHEST hoac tu lay them.");
            return;
        }
        if (r.skipped > 0) {
            state = State.BLOCKED;
            notifyEvery(300, "Con " + r.skipped + " vi tri chua den duoc (duong bi chan). Se thu lai sau.");
            return;
        }
        // het block thieu
        info("HOAN THANH: %d/%d block (%d%%). Block sai cho: %d (mod KHONG tu pha).",
            progress.done(), progress.total(), progress.percent(), progress.wrong());
        ConfigManager.d.hasProg = false;
        ConfigManager.save();
        toggle();
    }

    private void setTarget(BlockPos t) {
        target = t;
        stand = findStand(t);
        state = State.WALKING;
        idleTicks = 0; lastMoveTick = tick;
        lastPos = Util.pos(mc.player);
        BaritoneIntegration.forgetGoal();
    }

    private void walk(ClientPlayerEntity p) {
        state = State.WALKING;
        Goal g = stand != null ? new GoalBlock(stand) : new GoalNear(target, 3);
        BaritoneIntegration.goTo(g);

        Vec3d pos = Util.pos(p);
        if (pos.squaredDistanceTo(lastPos) > 0.25) { lastPos = pos; lastMoveTick = tick; }

        boolean busy = BaritoneIntegration.isBusy();
        idleTicks = busy ? 0 : idleTicks + 1;
        boolean noPath = idleTicks > 40 && !BaritoneIntegration.inGoal(g, p.getBlockPos());
        boolean stuck = busy && tick - lastMoveTick > 200;
        if (!noPath && !stuck) return;

        // khong tim duoc duong: thu AUTO GLASS (neu bat), nguoc lai bo qua muc tieu nay tam thoi
        AutoGlass glass = Modules.get().get(AutoGlass.class);
        if (glass != null && glass.isActive()) {
            BlockPos aim = stand != null ? stand : target;
            if (glass.tryBridge(aim)) { idleTicks = 0; lastMoveTick = tick; BaritoneIntegration.forgetGoal(); return; }
        }
        failStreak++;
        skipUntil.put(target.asLong(), tick + 1200);
        warning("Khong co duong toi %d %d %d. Bo qua tam thoi.", target.getX(), target.getY(), target.getZ());
        BaritoneIntegration.cancel();
        target = null; stand = null; idleTicks = 0;
    }

    private boolean inReach(ClientPlayerEntity p, BlockPos t) {
        Vec3d eye = p.getEyePos();
        double r = ConfigManager.d.reach;
        return eye.squaredDistanceTo(t.getX() + 0.5, t.getY() + 0.5, t.getZ() + 0.5) <= r * r;
    }

    private void notifyEvery(int ticks, String msg) {
        if (tick - lastMsgTick >= ticks) { lastMsgTick = tick; warning(msg); }
    }

    // ---------------- tim cho dung ----------------
    private boolean passable(BlockPos pos) {
        BlockState s = mc.world.getBlockState(pos);
        return s.getCollisionShape(mc.world, pos).isEmpty() && s.getFluidState().isEmpty();
    }

    private boolean solidFloor(BlockPos pos) {
        BlockState s = mc.world.getBlockState(pos);
        return !s.getCollisionShape(mc.world, pos).isEmpty() && s.getFluidState().isEmpty();
    }

    /** Vi tri dung (chan) gan nguoi choi nhat, trong tam voi block, khong chiem cho schematic can xay. */
    private BlockPos findStand(BlockPos t) {
        ClientPlayerEntity p = mc.player;
        double reach = ConfigManager.d.reach - 0.3;
        BlockPos best = null; double bestD = Double.MAX_VALUE;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -4; dx <= 4; dx++) for (int dz = -4; dz <= 4; dz++) for (int dy = -4; dy <= 1; dy++) {
            m.set(t.getX() + dx, t.getY() + dy, t.getZ() + dz);
            if (!mc.world.getChunkManager().isChunkLoaded(m.getX() >> 4, m.getZ() >> 4)) continue;
            Vec3d eye = new Vec3d(m.getX() + 0.5, m.getY() + 1.62, m.getZ() + 0.5);
            if (eye.squaredDistanceTo(t.getX() + 0.5, t.getY() + 0.5, t.getZ() + 0.5) > reach * reach) continue;
            BlockPos s = m.toImmutable();
            if (s.equals(t) || s.up().equals(t)) continue;
            if (!passable(s) || !passable(s.up()) || !solidFloor(s.down())) continue;
            if (!LitematicaIntegration.state(s).isAir() || !LitematicaIntegration.state(s.up()).isAir()) continue;
            double d = Util.pos(p).squaredDistanceTo(s.getX() + 0.5, s.getY(), s.getZ() + 0.5);
            if (d < bestD) { bestD = d; best = s; }
        }
        return best;
    }

    // ---------------- ve danh dau trong the gioi ----------------
    @EventHandler
    private void onRender(Render3DEvent e) {
        if (mc.player == null || !progress.hasPublished()) return;
        if (tick - nearbyDoneTick > 40) {
            nearbyDoneTick = tick;
            progress.nearbyDone(Util.pos(mc.player), 24, 300, nearbyDone);
        }
        Color gSide = new Color(40, 220, 90, 18), gLine = new Color(40, 220, 90, 110);
        for (BlockPos b : nearbyDone) e.renderer.box(b, gSide, gLine, ShapeMode.Lines, 0);
        if (target != null)
            e.renderer.box(target, new Color(255, 215, 0, 60), new Color(255, 215, 0, 255), ShapeMode.Both, 0);
        if (stand != null)
            e.renderer.box(stand, new Color(60, 160, 255, 40), new Color(60, 160, 255, 255), ShapeMode.Lines, 0);
    }

    @Override
    public String getInfoString() {
        return getState().name();
    }
}
