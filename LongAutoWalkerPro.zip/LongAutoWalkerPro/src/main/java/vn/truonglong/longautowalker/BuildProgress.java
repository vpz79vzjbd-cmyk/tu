package vn.truonglong.longautowalker;

import fi.dy.masa.litematica.schematic.placement.SchematicPlacement;
import fi.dy.masa.litematica.world.WorldSchematic;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.minecraft.block.Block;
import net.minecraft.block.BedBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.enums.BedPart;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

/**
 * Module 9: BuildProgress - quet schematic THEO TUNG DOT (budget block/tick) de khong lam lag.
 * Chi doc, khong sua schematic. Luu vi tri dang lam do.
 */
public final class BuildProgress {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private static final class Sweep {
        final LongArrayList missing = new LongArrayList();
        final LongArrayList done = new LongArrayList();
        final Map<Item, Integer> missingByItem = new HashMap<>();
        int total, wrong, unknown;
    }

    /** Ket qua chon block ke tiep. */
    public static final class Pick {
        public BlockPos pos;          // block se dat (co vat lieu trong tui)
        public int skipped;           // so block bi bo qua tam thoi (duong bi chan)
        public int noItem;            // so block con thieu nhung tui khong co vat lieu
        public Item firstNoItem;      // vat lieu can lay
        public BlockPos firstNoItemPos;
    }

    private Sweep cur = new Sweep(), pub = new Sweep();
    private boolean hasPub, sweeping;
    private int[][] boxes = new int[0][];
    private int bi, cx, cy, cz;
    private String key = "";
    private long publishedAtTick;

    public String key() { return key; }
    public boolean hasPublished() { return hasPub; }
    public int total() { return pub.total; }
    public int done() { return pub.done.size(); }
    public int missing() { return pub.missing.size(); }
    public int wrong() { return pub.wrong; }
    public int unknown() { return pub.unknown; }
    public Map<Item, Integer> missingByItem() { return new HashMap<>(pub.missingByItem); }
    public int percent() { return pub.total == 0 ? 0 : (int) (100L * pub.done.size() / pub.total); }

    /** @return null neu OK, nguoc lai la thong bao loi */
    public String start() {
        SchematicPlacement p = LitematicaIntegration.selected();
        if (p == null) return "Chua chon schematic placement trong Litematica.";
        if (LitematicaIntegration.world() == null) return "Schematic world chua san sang (hay tai placement trong Litematica).";
        List<int[]> b = LitematicaIntegration.boxes(p);
        if (b.isEmpty()) return "Placement khong co vung con nao dang bat.";
        key = LitematicaIntegration.key(p);
        boxes = b.toArray(new int[0][]);
        hasPub = false;
        pub = new Sweep();
        resetSweep();
        return null;
    }

    public void stop() { sweeping = false; hasPub = false; cur = new Sweep(); pub = new Sweep(); }

    private void resetSweep() {
        cur = new Sweep();
        bi = 0;
        if (boxes.length > 0) { cx = boxes[0][0]; cy = boxes[0][1]; cz = boxes[0][2]; }
        sweeping = boxes.length > 0;
    }

    private static boolean placeable(BlockState s) {
        Block b = s.getBlock();
        if (b.asItem() == Items.AIR) return false;
        if (s.contains(Properties.DOUBLE_BLOCK_HALF) && s.get(Properties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.UPPER) return false;
        if (b instanceof BedBlock && s.get(BedBlock.PART) == BedPart.HEAD) return false;
        return true;
    }

    /** Quet toi da `budget` block moi tick; hoan thanh 1 luot thi cong bo ket qua. */
    public void tick(int budget, long nowTick) {
        if (!sweeping) return;
        ClientWorld w = mc.world;
        WorldSchematic sw = LitematicaIntegration.world();
        if (w == null || sw == null) return;
        BlockPos.Mutable p = new BlockPos.Mutable();
        int n = 0;
        while (n < budget) {
            if (bi >= boxes.length) {
                pub = cur; hasPub = true; publishedAtTick = nowTick;
                resetSweep();
                return;
            }
            int[] b = boxes[bi];
            p.set(cx, cy, cz);
            n++;
            examine(w, sw, p);
            if (++cx > b[3]) {
                cx = b[0];
                if (++cz > b[5]) {
                    cz = b[2];
                    if (++cy > b[4]) {
                        bi++;
                        if (bi < boxes.length) { int[] nb = boxes[bi]; cx = nb[0]; cy = nb[1]; cz = nb[2]; }
                    }
                }
            }
        }
    }

    private void examine(ClientWorld w, WorldSchematic sw, BlockPos.Mutable p) {
        BlockState s = sw.getBlockState(p);
        if (s.isAir() || !placeable(s)) return;
        cur.total++;
        if (!w.getChunkManager().isChunkLoaded(p.getX() >> 4, p.getZ() >> 4)) { cur.unknown++; return; }
        BlockState ws = w.getBlockState(p);
        if (ws.getBlock() == s.getBlock()) cur.done.add(p.asLong());
        else if (ws.isAir() || ws.isReplaceable()) {
            cur.missing.add(p.asLong());
            cur.missingByItem.merge(s.getBlock().asItem(), 1, Integer::sum);
        } else cur.wrong++;
    }

    // ---------- kiem tra tuc thoi (khong cho het luot quet) ----------

    /** true neu block dung loai da duoc dat tai pos (nguoi choi vua dat xong). */
    public boolean isDoneLive(BlockPos pos) {
        BlockState s = LitematicaIntegration.state(pos);
        if (s.isAir()) return true;
        return mc.world.getBlockState(pos).getBlock() == s.getBlock();
    }

    public boolean isMissingLive(BlockPos pos) {
        BlockState s = LitematicaIntegration.state(pos);
        if (s.isAir() || !placeable(s)) return false;
        if (!mc.world.getChunkManager().isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4)) return false;
        BlockState ws = mc.world.getBlockState(pos);
        return ws.getBlock() != s.getBlock() && (ws.isAir() || ws.isReplaceable());
    }

    public static Item itemAt(BlockPos pos) {
        return LitematicaIntegration.state(pos).getBlock().asItem();
    }

    /**
     * Chon block ke tiep: tang thap nhat truoc, gan nguoi choi nhat, chi chon block ma tui co vat lieu.
     * Danh sach `missing` duoc quet theo y tang dan nen chi duyet het tang thap nhat roi dung.
     */
    public Pick pickNext(Vec3d from, Map<Item, Integer> inv, Predicate<Long> skip) {
        Pick r = new Pick();
        long bestKey = 0; double bestD = Double.MAX_VALUE; int bestY = Integer.MAX_VALUE;
        LongArrayList list = pub.missing;
        for (int i = 0, n = list.size(); i < n; i++) {
            long l = list.getLong(i);
            BlockPos pos = BlockPos.fromLong(l);
            if (pos.getY() > bestY) break;
            if (!isMissingLive(pos)) continue;
            Item it = itemAt(pos);
            if (inv.getOrDefault(it, 0) <= 0) {
                r.noItem++;
                if (r.firstNoItem == null) { r.firstNoItem = it; r.firstNoItemPos = pos; }
                continue;
            }
            if (skip.test(l)) { r.skipped++; continue; }
            double d = from.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
            if (pos.getY() < bestY || d < bestD) { bestY = pos.getY(); bestD = d; bestKey = l; r.pos = pos; }
        }
        return r;
    }

    /** Cac block da hoan thanh quanh `c` (de ve danh dau), toi da `max`. */
    public void nearbyDone(Vec3d c, double radius, int max, java.util.List<BlockPos> out) {
        out.clear();
        double r2 = radius * radius;
        LongArrayList list = pub.done;
        for (int i = 0, n = list.size(); i < n && out.size() < max; i++) {
            BlockPos pos = BlockPos.fromLong(list.getLong(i));
            if (c.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= r2) out.add(pos);
        }
    }
}
