package vn.truonglong.longautowalker;

import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.utils.CharFilter;
import meteordevelopment.meteorclient.gui.widgets.WLabel;
import meteordevelopment.meteorclient.gui.widgets.containers.WHorizontalList;
import meteordevelopment.meteorclient.gui.widgets.containers.WSection;
import meteordevelopment.meteorclient.gui.widgets.input.WTextBox;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.gui.widgets.pressable.WCheckbox;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;

/** Module 11: MainMenu - giao dien chinh (dung bo widget/theme cua Meteor de dong bo giao dien). */
public class MainMenu extends WindowScreen {
    private static final CharFilter INT = (text, c) -> Character.isDigit(c) || (c == '-' && text.isEmpty());

    private final AutoWalk walk = Modules.get().get(AutoWalk.class);
    private final AutoChest chest = Modules.get().get(AutoChest.class);
    private final AutoGlass glass = Modules.get().get(AutoGlass.class);

    private WButton bChest, bGlass;
    private WTextBox tz, ty, tx;
    private WLabel lState, lPlacement, lTotal, lDone, lMissing, lWrong, lNext, lTarget, lPos, lSel, lChestMsg, lGlass;

    public MainMenu(GuiTheme theme) { super(theme, "LONG AUTO WALKER PRO"); }

    @Override
    public void initWidgets() {
        // ---- dieu khien chinh ----
        WHorizontalList r1 = add(theme.horizontalList()).expandX().widget();
        r1.add(theme.button("START WALK")).expandX().widget().action = walk::startWalk;
        r1.add(theme.button("PAUSE")).expandX().widget().action = walk::pauseWalk;
        r1.add(theme.button("RESUME")).expandX().widget().action = walk::resumeWalk;
        r1.add(theme.button("STOP")).expandX().widget().action = walk::stopWalk;

        WHorizontalList r2 = add(theme.horizontalList()).expandX().widget();
        bChest = r2.add(theme.button(toggleText("AUTO CHEST", chest))).expandX().widget();
        bChest.action = () -> { chest.toggle(); refreshToggles(); };
        bGlass = r2.add(theme.button(toggleText("AUTO GLASS", glass))).expandX().widget();
        bGlass.action = () -> { glass.toggle(); refreshToggles(); };

        WHorizontalList r3 = add(theme.horizontalList()).expandX().widget();
        r3.add(theme.button("+ SELECT BLOCK")).expandX().widget().action = () -> BlockSelector.openScreen(theme);
        r3.add(theme.button("REPORT GLASS")).expandX().widget().action = glass::reportGlass;
        lSel = add(theme.label("")).widget();

        // ---- toa do ruong: thu tu Z, Y, X ----
        WSection sc = add(theme.section("CHEST COORDINATES", true)).expandX().widget();
        ConfigManager.Data d = ConfigManager.d;
        WHorizontalList cr = sc.add(theme.horizontalList()).expandX().widget();
        cr.add(theme.label("Z:"));
        tz = cr.add(theme.textBox(d.hasChest ? String.valueOf(d.chestZ) : "", INT)).minWidth(70).widget();
        cr.add(theme.label("Y:"));
        ty = cr.add(theme.textBox(d.hasChest ? String.valueOf(d.chestY) : "", INT)).minWidth(70).widget();
        cr.add(theme.label("X:"));
        tx = cr.add(theme.textBox(d.hasChest ? String.valueOf(d.chestX) : "", INT)).minWidth(70).widget();
        WButton save = cr.add(theme.button("SAVE")).widget();
        save.action = this::saveChest;
        lChestMsg = sc.add(theme.label(d.hasChest ? "Da luu ruong." : "Chua luu ruong.")).widget();

        // ---- tien do ----
        WSection sp = add(theme.section("BUILD PROGRESS", true)).expandX().widget();
        lState = sp.add(theme.label("")).widget();
        lPlacement = sp.add(theme.label("")).widget();
        lTotal = sp.add(theme.label("")).widget();
        lDone = sp.add(theme.label("")).widget();
        lMissing = sp.add(theme.label("")).widget();
        lWrong = sp.add(theme.label("")).widget();
        lNext = sp.add(theme.label("")).widget();
        lTarget = sp.add(theme.label("")).widget();
        lPos = sp.add(theme.label("")).widget();
        lGlass = sp.add(theme.label("")).widget();

        // ---- cai dat: phim tat + cho phep tren server ----
        WSection ss = add(theme.section("SETTINGS", false)).expandX().widget();
        WHorizontalList sv = ss.add(theme.horizontalList()).expandX().widget();
        sv.add(theme.label("Allow on servers (chi bat khi server cho phep tu dong hoa): "));
        WCheckbox cb = sv.add(theme.checkbox(ConfigManager.d.allowOnServers)).widget();
        cb.action = () -> { ConfigManager.d.allowOnServers = cb.checked; ConfigManager.save(); };
        keyRow(ss, "Phim Auto Walk", walk);
        keyRow(ss, "Phim Auto Chest", chest);
        keyRow(ss, "Phim Auto Glass", glass);
        keyRow(ss, "Phim mo Menu", Modules.get().get(MenuModule.class));

        update();
    }

    private void keyRow(WSection s, String label, Module m) {
        WHorizontalList row = s.add(theme.horizontalList()).expandX().widget();
        row.add(theme.label(label + ": "));
        row.add(theme.keybind(m.keybind));
    }

    private static String toggleText(String n, Module m) { return n + ": " + (m.isActive() ? "ON" : "OFF"); }

    private void refreshToggles() {
        bChest.set(toggleText("AUTO CHEST", chest));
        bGlass.set(toggleText("AUTO GLASS", glass));
    }

    private void saveChest() {
        try {
            int z = Integer.parseInt(tz.get().trim()), y = Integer.parseInt(ty.get().trim()), x = Integer.parseInt(tx.get().trim());
            ConfigManager.Data d = ConfigManager.d;
            d.chestX = x; d.chestY = y; d.chestZ = z; d.hasChest = true;
            ConfigManager.save();
            lChestMsg.set("Da luu ruong: " + x + " " + y + " " + z);
        } catch (NumberFormatException e) {
            lChestMsg.set("Toa do khong hop le (can so nguyen cho Z, Y, X).");
        }
    }

    private static String xyz(BlockPos p) { return p == null ? "-" : p.getX() + " " + p.getY() + " " + p.getZ(); }

    @Override
    public void tick() {
        super.tick();
        update();
    }

    private void update() {
        if (lState == null) return;
        var bp = walk.progress();
        var p = MinecraftClient.getInstance().player;
        lState.set("Trang thai: " + walk.getState());
        lPlacement.set("Schematic: " + (walk.isActive() ? bp.key() : "(chua chay)"));
        lTotal.set("Tong block can xay: " + bp.total());
        lDone.set("Da hoan thanh: " + bp.done() + " (" + bp.percent() + "%)");
        lMissing.set("Con thieu: " + bp.missing() + "   Sai cho (khong tu pha): " + bp.wrong());
        lNext.set("Block can dat tiep: " + walk.nextBlockText());
        lTarget.set("Muc tieu: " + xyz(walk.getTarget()) + "   Cho dung: " + xyz(walk.getStand()));
        lPos.set("Vi tri hien tai: " + (p == null ? "-" : xyz(p.getBlockPos())));
        lGlass.set("Glass can thu hoi: " + glass.glassCount());
        lSel.set("Block da chon de lay tu ruong: " + BlockSelector.count());
        refreshToggles();
    }
}
