package vn.truonglong.longautowalker;

import meteordevelopment.meteorclient.gui.GuiThemes;
import meteordevelopment.meteorclient.systems.modules.Module;

/** Module nho: nhan phim (mac dinh K) de mo MainMenu. */
public class MenuModule extends Module {
    public MenuModule() {
        super(MeteorIntegration.CATEGORY, "long-menu", "Mo menu Long Auto Walker PRO.");
        chatFeedback = false;
    }

    @Override
    public void onActivate() {
        toggle();
        mc.setScreen(new MainMenu(GuiThemes.get()));
    }
}
